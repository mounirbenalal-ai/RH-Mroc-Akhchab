/**
 * Driving-AI 2026: The Ultimate Global Signs Encyclopedia
 * تم بناء هذا المحرك بناءً على تصنيفات "أبو حمزة لتعليم السياقة" والمعايير الدولية.
 */

const GlobalSignsEncyclopedia = {
    // 1. الإشارات التحذيرية (Warning Signs)
    warning: [
        { id: "W1", title: "أمامك دوار", desc: "ينبه السائق لوجود تقاطع طرق دائري أمامك.", icon: "⚠️🔄" },
        { id: "W2", title: "طريق زلقة", desc: "تحذير من أن الطريق قد تكون ملساء بسبب الأمطار أو الزيوت.", icon: "⚠️🚗" },
        { id: "W3", title: "أمامك إشارة ضوئية", desc: "تنبيه للاستعداد للتوقف عند إشارات المرور الضوئية.", icon: "⚠️🚦" }
    ],

    // 2. الإشارات المانعة (Prohibitory Signs)
    prohibitory: [
        { id: "P1", title: "ممنوع الدخول", desc: "يمنع دخول جميع أنواع المركبات في هذا الاتجاه.", icon: "⛔" },
        { id: "P2", title: "ممنوع التجاوز", desc: "يمنع على السيارات تجاوز المركبات الأخرى في هذا المقطع.", icon: "🚫🚗" },
        { id: "P3", title: "ممنوع الوقوف", desc: "يمنع ركن السيارة في هذا المكان.", icon: "🚫🅿️" }
    ],

    // 3. الإشارات الإجبارية والملزمة (Mandatory Signs)
    mandatory: [
        { id: "M1", title: "اتجاه إجباري لليمين", desc: "يجب على جميع السائقين الانعطاف يميناً.", icon: "🔵➡️" },
        { id: "M2", title: "ممر خاص للدراجات", desc: "طريق مخصص حصرياً لراكبي الدراجات.", icon: "🔵🚲" }
    ],

    // 4. الإشارات الآمرة (Priority Signs)
    priority: [
        { id: "PR1", title: "قف (STOP)", desc: "وجوب التوقف التام عند الخط وإعطاء الأولوية.", icon: "🛑" },
        { id: "PR2", title: "أعطِ الأولوية", desc: "يجب التمهل وإعطاء حق المرور للقادمين من الطريق الرئيسي.", icon: "🔻" }
    ],

    // 5. علامات المرور الأرضية والضوئية (Road Markings & Signals)
    roadElements: [
        { id: "R1", title: "خطوط المشاة", desc: "تحدد المنطقة الآمنة لعبور الراجلين.", icon: "🦓" },
        { id: "S1", title: "إشارة ضوئية حمراء", desc: "تعني التوقف التام خلف خط الوقوف.", icon: "🔴" }
    ]
};

// المحرك الخارق للعرض والبحث
const SignsUltraEngine = {
    // وظيفة توليد الموسوعة كاملة بتصميم عصري
    generateEncyclopediaHTML() {
        let html = '<div class="encyclopedia-wrapper">';
        
        for (const category in GlobalSignsEncyclopedia) {
            html += `<h2 class="category-header">${this.getCategoryTitle(category)}</h2>`;
            html += '<div class="signs-grid">';
            
            GlobalSignsEncyclopedia[category].forEach(sign => {
                html += `
                    <div class="ultra-card" onclick="SignsUltraEngine.speakSign('${sign.title}')">
                        <div class="ultra-icon">${sign.icon}</div>
                        <h3>${sign.title}</h3>
                        <p>${sign.desc}</p>
                        <span class="sign-id">ID: ${sign.id}</span>
                    </div>`;
            });
            html += '</div>';
        }
        html += '</div>';
        return html;
    },

    getCategoryTitle(cat) {
        const titles = {
            warning: "⚠️ الإشارات التحذيرية",
            prohibitory: "🚫 الإشارات المانعة",
            mandatory: "🔵 الإشارات الإجبارية",
            priority: "🛑 الإشارات الآمرة",
            roadElements: "🛤️ العلامات الأرضية والضوئية"
        };
        return titles[cat] || cat;
    },

    // ميزة التطور: نطق اسم العلامة عند الضغط عليها
    speakSign(text) {
        const msg = new SpeechSynthesisUtterance();
        msg.text = text;
        msg.lang = 'ar-SA';
        window.speechSynthesis.speak(msg);
    }
};
